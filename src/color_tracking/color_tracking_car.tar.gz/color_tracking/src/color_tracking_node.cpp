/*
 *  To run off a webcam comment lines 9-11
 *  call image_source using 1
 *  to run using ROS uncomment lines 9-11
 *  call image_source using 0
 * */

// Uncomment this block to run on ROS these are catkin components
// that get linked using the CMakeRequiredments.txt
#include <ros/ros.h>
#include <cv_bridge/cv_bridge.h>
#include <image_transport/image_transport.h>

#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <iostream>
#include <stdlib.h>
//
#include <ctime>
#include <iostream>


#ifdef MEASURE_TIME
t_begin = clock();
#endif


/*
 * optimizations:
 * minimize the number of new mats made. So far we could rewrite the ones we have
 * but I am not to allow more flexibility in the future
 *
 */

// ########## GLOBALS ########
using namespace std;

// low to filter out orange
int iLowH = 0;
int iHighH = 8;

int iLowH_2 = 162;
int iHighH_2 = 179;

int iLowS = 146;
int iHighS = 255;

int iLowS_2 = 146;
int iHighS_2 = 255;

int iLowV = 77;
int iHighV = 255;

int iLowV_2 = 77;
int iHighV_2 = 255;

int blur1 = 1;
int blur2 = 1;

cv::RNG rng(12345);

// ########  End Globals #######

int check_webcam(const cv::VideoCapture & cap){

    // Break if webcam does not work

    if ( !cap.isOpened() )  // if device is not accessible
    {
        cout << "Cannot open webcam" << endl;
        return 0;
    }
    else{
        return 1;
    }
} 
//#define MEASURE_TIME 1
#define COLOR_TRACKING 1

#ifdef MEASURE_TIME
clock_t t_begin = 0;
#endif

int myMin(int a, int b){
    if (a < b){
        return a;
    }
    else{
        return b;
    }
}

int myMax(int a, int b) {
    if (a > b) {
        return a;
    } else {
        return b;
    }
}

void findEdgeElems (const cv::Mat& input_img)
{

    // Pre-process image to help build contours
    cv::Mat edge_output_img;

    // Every contour or chunk of detected object is represented as a vector of points
    vector<vector<cv::Point> > contours;

    // Contains topological information of the contour points. This way we have more data of neighboring points
    // by observing a single one
    // http://docs.opencv.org/2.4/modules/imgproc/doc/structural_analysis_and_shape_descriptors.html?highlight=findcontours#findcontours
    vector<cv::Vec4i> hierarchy;

    cv::Mat img;
    cv::blur(input_img, img, cv::Size(15,15) );

    double t1 = 20;
    double t2 = 50;
    int apertureSize = 3;

    cv::threshold( img, img, 100, 255, cv::THRESH_BINARY );
    cv::Canny(img, edge_output_img, t1, t2, apertureSize);
    // Fiddle here
    cv::Size s1(myMax(blur1,1), myMax(blur1,1));
    cv::Size s2(myMax(blur1,1), myMax(blur1,1));
    cv::blur(edge_output_img, edge_output_img, s1 );
    cv::threshold( img, img, 100, 255, cv::THRESH_BINARY );
    cv::blur(edge_output_img, edge_output_img, s2 );

    // double values of resulting image
    edge_output_img = edge_output_img | edge_output_img;
    // stop fiddling

    // Tracking / drawing

    findContours( edge_output_img, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, cv::Point(0, 0) );

    vector<vector<cv::Point> > contours_poly( contours.size() );
    vector<cv::Rect> boundRect( contours.size() );
    vector<cv::Point2f>center( contours.size() );

    vector<float>radius( contours.size() );

    int iters = myMin(contours.size(), 1);

    for( int i = 0; i < iters; i++ )
    {
        approxPolyDP( cv::Mat(contours[i]), contours_poly[i], 3, true );
        boundRect[i] = boundingRect( cv::Mat(contours_poly[i]) );
        minEnclosingCircle( (cv::Mat)contours_poly[i], center[i], radius[i] );
    }

    /// Draw polygonal contour + bonding rects + circles
    cv::Mat contour_img = cv::Mat::zeros( edge_output_img.size(), CV_8UC3 );

    for( int i = 0; i< iters; i++ )
    {
        cv::Scalar color = cv::Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
        drawContours( contour_img, contours_poly, i, color, 1, 8, vector<cv::Vec4i>(), 0, cv::Point() );
        rectangle( contour_img, boundRect[i].tl(), boundRect[i].br(), color, 2, 8, 0 );
        circle( contour_img, center[i], (int)radius[i], color, 2, 8, 0 );
    }
/*
    cv::namedWindow( "pre-contour", CV_WINDOW_AUTOSIZE );
    cv::imshow( "pre-contour", edge_output_img );

    cv::namedWindow( "Contours", CV_WINDOW_AUTOSIZE );
    cv::imshow( "Contours", contour_img );
*/
}

void make_control(){

    cv::namedWindow("sliders", CV_WINDOW_AUTOSIZE); //create a sliders window
    // (tag, window, data field, start)
    cvCreateTrackbar("LowH", "sliders", &iLowH, 179); //Hue (0 - 179)
    cvCreateTrackbar("HighH", "sliders", &iHighH, 179);
    cvCreateTrackbar("LowH_2", "sliders", &iLowH_2, 179);
    cvCreateTrackbar("HighH_2", "sliders", &iHighH_2, 179);

    cvCreateTrackbar("LowS", "sliders", &iLowS, 255); //Saturation (0 - 255)
    cvCreateTrackbar("HighS", "sliders", &iHighS, 255);
    cvCreateTrackbar("LowS_2", "sliders", &iLowS_2, 255);
    cvCreateTrackbar("HighS_2", "sliders", &iHighS_2, 255);

    cvCreateTrackbar("LowV", "sliders", &iLowV_2, 255); //Value (0 - 255)
    cvCreateTrackbar("HighV", "sliders", &iHighV_2, 255);
    cvCreateTrackbar("LowV_2", "sliders", &iLowV_2, 255);
    cvCreateTrackbar("HighV_2", "sliders", &iHighV_2, 255);


    cvCreateTrackbar("blur_1", "sliders", &blur1, 100);
    cvCreateTrackbar("blur_2", "sliders", &blur2, 100);


}

void cv_process_img(const cv::Mat& input_img, cv::Mat& output_img)
{
   cv::Mat gray_img;
   cv::cvtColor(input_img, gray_img, CV_RGB2GRAY);
   
   double t1 = 20;
   double t2 = 50;
   int apertureSize = 3;
   
   cv::Canny(gray_img, output_img, t1, t2, apertureSize); 
}



void cv_color_tracking(const cv::Mat &imgHSV, cv::Mat &imgThresholded_red_1, cv::Mat &imgThresholded_red_2){
    // an HSV image, and two blank threshold Mats, result is saved in third parameter ( thresholded_red_2 )

    // filter all hsv values that are not defined by us (or our sliders)
    cv::inRange(imgHSV, cv::Scalar(iLowH, iLowS, iLowV), cv::Scalar(iHighH, iHighS, iHighV), imgThresholded_red_1); //Threshold the image
    cv::inRange(imgHSV, cv::Scalar(iLowH_2, iLowS_2, iLowV_2), cv::Scalar(iHighH_2, iHighS_2, iHighV_2), imgThresholded_red_2); //Threshold the image

/*    cv::imshow("Threshold_1", imgThresholded_red_1); //show the thresholded image
    cv::imshow("Threshold_2", imgThresholded_red_2); //show the thresholded image
*/
    // superimpose both images to gather all red from both ranges of the HSV sprectrum
    imgThresholded_red_2 = imgThresholded_red_1 | imgThresholded_red_2;

    //morphological opening (remove small objects from the foreground)
    cv::erode(imgThresholded_red_2, imgThresholded_red_2, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5)) );
    cv::dilate( imgThresholded_red_2, imgThresholded_red_2, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5)) );

    // I am not sure if we really need to do this twice.
    //morphological closing (fill small holes in the foreground)
    cv::erode(imgThresholded_red_2, imgThresholded_red_2, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5)) );
    cv::dilate( imgThresholded_red_2, imgThresholded_red_2, cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5)) );

   // cv::imshow("Erode + Dilate", imgThresholded_red_2); //show the thresholded image

}

void cv_publish_img(image_transport::Publisher &pub, cv::Mat& pub_img)
{
	//sensor_msgs::ImagePtr pub_msg = cv_bridge::CvImage(std_msgs::Header(), "bgr8", pub_img).toImageMsg();
	sensor_msgs::ImagePtr pub_msg = cv_bridge::CvImage(std_msgs::Header(), "mono8", pub_img).toImageMsg();
	pub.publish(pub_msg);
}

void imageCallback(const sensor_msgs::ImageConstPtr& msg_frame, image_transport::Publisher &pub)
{
    cv_bridge::CvImageConstPtr cv_ori_img_ptr;
    // capture image
	cv::Mat cv_ori_img;
    try{
        cv_ori_img = cv_bridge::toCvShare(msg_frame, "bgr8")->image;
    }catch(cv_bridge::Exception& e){
        ROS_ERROR("Could not convert from '%s' to 'bgr8'.", msg_frame->encoding.c_str());
    }
	cv::imshow("Foo test", cv_ori_img); // testing X-forwarding issues
        // next two lines are the inputs for color detection
        cv::Mat cv_blank_mat;
        cv::Mat cv_color_detect_output;

        // input for edge detection
        cv::Mat cv_edge_output_img;

        // if you want to publish the edges, run this line (we don't want to, so far)
        //cv_RGB2Grey(cv_ori_img, cv_edge_output_img);
        //cv_publish_img(pub, cv_color_edge_output);

        // color detection, no idea why we are using the ifdef (TA) did it.
        #ifdef COLOR_TRACKING
        cv_color_tracking(cv_ori_img, cv_blank_mat, cv_color_detect_output);
        #endif

        // if you want to publish the color detection (we don't want to, so far)
        //cv_publish_img(pub, cv_color_detect_output);

        #ifdef MEASURE_TIME
        clock_t t_end = clock();
        double delta_time= double(t_end - t_begin) / CLOCKS_PER_SEC;
        cout << "Delta_t = " << 1/delta_time << "\n";
        //t_begin = t_end;
        #endif

        // wait for "shutter" to have time to take a picture
        cv::waitKey(30);

        #ifdef MEASURE_TIME
        t_begin = clock();
        #endif

}


int main(int argc, char **argv)
{
	//	make_control()

    ros::init(argc, argv, "image_listener");

    ros::NodeHandle nh;
    
    image_transport::ImageTransport it(nh);
	
	ros::NodeHandle nh_pub;
	image_transport::ImageTransport itpub(nh_pub);
	image_transport::Publisher pub = itpub.advertise("sample/cannyimg", 1);

    #ifdef MEASURE_TIME
    t_begin = clock();
    #endif

    image_transport::Subscriber sub = it.subscribe("rgb/image_rect", 1, boost::bind(imageCallback, _1, pub));
    ros::spin();
    //cv::destroyWindow("view");
    
}
